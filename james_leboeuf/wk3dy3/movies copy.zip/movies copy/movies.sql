CREATE TABLE movies (
	id INTEGER PRIMARY KEY AUTOINCREMENT,
	poster TEXT,
	plot TEXT,
	year TEXT,
	title TEXT,
	imdbid TEXT
);